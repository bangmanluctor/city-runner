extends Area2D

var entered = false



func _on_body_entered(body: CharacterBody2D) -> void:
	entered = true
	
func _process(_delta):
	if entered == true:
		
